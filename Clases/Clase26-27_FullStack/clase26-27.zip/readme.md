# Proyecto Fullstack

### Dependencias back:  
cors, express, mysql2, sequelize

